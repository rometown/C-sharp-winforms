﻿namespace WeeklyAssignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblScreen = new System.Windows.Forms.Label();
            this.btnBackspace = new System.Windows.Forms.Button();
            this.btnSubtract = new System.Windows.Forms.Button();
            this.btnMultiply = new System.Windows.Forms.Button();
            this.btnDivide = new System.Windows.Forms.Button();
            this.btnSeven = new System.Windows.Forms.Button();
            this.btnEight = new System.Windows.Forms.Button();
            this.btnNine = new System.Windows.Forms.Button();
            this.btnFour = new System.Windows.Forms.Button();
            this.btnFive = new System.Windows.Forms.Button();
            this.btnSix = new System.Windows.Forms.Button();
            this.btnOne = new System.Windows.Forms.Button();
            this.btnTwo = new System.Windows.Forms.Button();
            this.btnThree = new System.Windows.Forms.Button();
            this.btnZero = new System.Windows.Forms.Button();
            this.btnDecimal = new System.Windows.Forms.Button();
            this.btnEquals = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblCurrentOperation = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnAdd, "btnAdd");
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.operatorButton_Click);
            // 
            // lblScreen
            // 
            this.lblScreen.BackColor = System.Drawing.Color.White;
            this.lblScreen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.lblScreen, "lblScreen");
            this.lblScreen.Name = "lblScreen";
            // 
            // btnBackspace
            // 
            this.btnBackspace.BackColor = System.Drawing.Color.Black;
            this.btnBackspace.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnBackspace, "btnBackspace");
            this.btnBackspace.ForeColor = System.Drawing.Color.White;
            this.btnBackspace.Name = "btnBackspace";
            this.btnBackspace.UseVisualStyleBackColor = false;
            this.btnBackspace.Click += new System.EventHandler(this.btnBackspace_Click);
            // 
            // btnSubtract
            // 
            this.btnSubtract.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnSubtract, "btnSubtract");
            this.btnSubtract.ForeColor = System.Drawing.Color.White;
            this.btnSubtract.Name = "btnSubtract";
            this.btnSubtract.UseVisualStyleBackColor = true;
            this.btnSubtract.Click += new System.EventHandler(this.operatorButton_Click);
            // 
            // btnMultiply
            // 
            this.btnMultiply.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnMultiply, "btnMultiply");
            this.btnMultiply.ForeColor = System.Drawing.Color.White;
            this.btnMultiply.Name = "btnMultiply";
            this.btnMultiply.UseVisualStyleBackColor = true;
            this.btnMultiply.Click += new System.EventHandler(this.operatorButton_Click);
            // 
            // btnDivide
            // 
            this.btnDivide.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnDivide, "btnDivide");
            this.btnDivide.ForeColor = System.Drawing.Color.White;
            this.btnDivide.Name = "btnDivide";
            this.btnDivide.UseVisualStyleBackColor = true;
            this.btnDivide.Click += new System.EventHandler(this.operatorButton_Click);
            // 
            // btnSeven
            // 
            this.btnSeven.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnSeven, "btnSeven");
            this.btnSeven.ForeColor = System.Drawing.Color.White;
            this.btnSeven.Name = "btnSeven";
            this.btnSeven.UseVisualStyleBackColor = true;
            this.btnSeven.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnEight
            // 
            this.btnEight.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnEight, "btnEight");
            this.btnEight.ForeColor = System.Drawing.Color.White;
            this.btnEight.Name = "btnEight";
            this.btnEight.UseVisualStyleBackColor = true;
            this.btnEight.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnNine
            // 
            this.btnNine.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnNine, "btnNine");
            this.btnNine.ForeColor = System.Drawing.Color.White;
            this.btnNine.Name = "btnNine";
            this.btnNine.UseVisualStyleBackColor = true;
            this.btnNine.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnFour
            // 
            this.btnFour.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnFour, "btnFour");
            this.btnFour.ForeColor = System.Drawing.Color.White;
            this.btnFour.Name = "btnFour";
            this.btnFour.UseVisualStyleBackColor = true;
            this.btnFour.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnFive
            // 
            this.btnFive.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnFive, "btnFive");
            this.btnFive.ForeColor = System.Drawing.Color.White;
            this.btnFive.Name = "btnFive";
            this.btnFive.UseVisualStyleBackColor = true;
            this.btnFive.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnSix
            // 
            this.btnSix.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnSix, "btnSix");
            this.btnSix.ForeColor = System.Drawing.Color.White;
            this.btnSix.Name = "btnSix";
            this.btnSix.UseVisualStyleBackColor = true;
            this.btnSix.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnOne
            // 
            this.btnOne.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnOne, "btnOne");
            this.btnOne.ForeColor = System.Drawing.Color.White;
            this.btnOne.Name = "btnOne";
            this.btnOne.UseVisualStyleBackColor = true;
            this.btnOne.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnTwo
            // 
            this.btnTwo.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnTwo, "btnTwo");
            this.btnTwo.ForeColor = System.Drawing.Color.White;
            this.btnTwo.Name = "btnTwo";
            this.btnTwo.UseVisualStyleBackColor = true;
            this.btnTwo.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnThree
            // 
            this.btnThree.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnThree, "btnThree");
            this.btnThree.ForeColor = System.Drawing.Color.White;
            this.btnThree.Name = "btnThree";
            this.btnThree.UseVisualStyleBackColor = true;
            this.btnThree.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnZero
            // 
            this.btnZero.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnZero, "btnZero");
            this.btnZero.ForeColor = System.Drawing.Color.White;
            this.btnZero.Name = "btnZero";
            this.btnZero.UseVisualStyleBackColor = true;
            this.btnZero.Click += new System.EventHandler(this.numberButton_Click);
            // 
            // btnDecimal
            // 
            this.btnDecimal.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnDecimal, "btnDecimal");
            this.btnDecimal.ForeColor = System.Drawing.Color.White;
            this.btnDecimal.Name = "btnDecimal";
            this.btnDecimal.UseVisualStyleBackColor = true;
            this.btnDecimal.Click += new System.EventHandler(this.btnDecimal_Click);
            // 
            // btnEquals
            // 
            this.btnEquals.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnEquals, "btnEquals");
            this.btnEquals.ForeColor = System.Drawing.Color.White;
            this.btnEquals.Name = "btnEquals";
            this.btnEquals.UseVisualStyleBackColor = true;
            this.btnEquals.Click += new System.EventHandler(this.btnEquals_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Black;
            this.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnClear, "btnClear");
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Name = "btnClear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblCurrentOperation
            // 
            this.lblCurrentOperation.BackColor = System.Drawing.SystemColors.Control;
            this.lblCurrentOperation.ForeColor = System.Drawing.Color.Gray;
            resources.ApplyResources(this.lblCurrentOperation, "lblCurrentOperation");
            this.lblCurrentOperation.Name = "lblCurrentOperation";
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.Controls.Add(this.lblCurrentOperation);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnEquals);
            this.Controls.Add(this.btnDecimal);
            this.Controls.Add(this.btnZero);
            this.Controls.Add(this.btnThree);
            this.Controls.Add(this.btnTwo);
            this.Controls.Add(this.btnOne);
            this.Controls.Add(this.btnSix);
            this.Controls.Add(this.btnFive);
            this.Controls.Add(this.btnFour);
            this.Controls.Add(this.btnNine);
            this.Controls.Add(this.btnEight);
            this.Controls.Add(this.btnSeven);
            this.Controls.Add(this.btnDivide);
            this.Controls.Add(this.btnMultiply);
            this.Controls.Add(this.btnSubtract);
            this.Controls.Add(this.btnBackspace);
            this.Controls.Add(this.lblScreen);
            this.Controls.Add(this.btnAdd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPress);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lblScreen;
        private System.Windows.Forms.Button btnBackspace;
        private System.Windows.Forms.Button btnSubtract;
        private System.Windows.Forms.Button btnMultiply;
        private System.Windows.Forms.Button btnDivide;
        private System.Windows.Forms.Button btnSeven;
        private System.Windows.Forms.Button btnEight;
        private System.Windows.Forms.Button btnNine;
        private System.Windows.Forms.Button btnFour;
        private System.Windows.Forms.Button btnFive;
        private System.Windows.Forms.Button btnSix;
        private System.Windows.Forms.Button btnOne;
        private System.Windows.Forms.Button btnTwo;
        private System.Windows.Forms.Button btnThree;
        private System.Windows.Forms.Button btnZero;
        private System.Windows.Forms.Button btnDecimal;
        private System.Windows.Forms.Button btnEquals;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblCurrentOperation;
    }
}

