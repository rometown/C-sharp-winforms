﻿// Author: Millora, Romeo
// Assignment 02
// Feb. 1, 2016

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


namespace WeeklyAssignment
{
    public partial class Form1 : Form
    {
        double result = 0;             // Display when user presses the "=" button

        string mathOperator = "";       // + - * /
        double lastValueEntered = 0;
        string lastKeyPressed = null;
        bool EqualsButtonPressed = false;


        public Form1()
        {
            InitializeComponent();
        }


        private void UpdateResult()
        {
            try
            {
                MyClassLibrary.MyCalcLibrary mcl = new MyClassLibrary.MyCalcLibrary();

                lblCurrentOperation.Text = result.ToString() + " " + mathOperator + " " + lastValueEntered.ToString();


                switch (mathOperator)
                {
                    case "+":
                        result = mcl.Add(result, lastValueEntered);
                        lblScreen.Text = result.ToString();
                        break;
                    case "-":
                        result = mcl.Subtract(result, lastValueEntered);
                        lblScreen.Text = result.ToString();
                        break;
                    case "*":
                        result = mcl.Multiply(result, lastValueEntered);
                        lblScreen.Text = result.ToString();
                        break;
                    case "/":
                        if (lastValueEntered == 0)
                        {
                            lblScreen.Text = "N/A";

                            ClearFields();
                        }
                        else
                        {
                            result = mcl.Divide(result, lastValueEntered);
                            lblScreen.Text = result.ToString();
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException(string.Format("Exception while calculating the result."), ex);
            }
            
        }
        // end UpdateResult

        private void operatorButton_Click(object sender, EventArgs e)
        {
            if (mathOperator != "" && EqualsButtonPressed != true)
            {
                UpdateResult();
            }
            else
            {
                result = double.Parse(lblScreen.Text);
            }

            Button button = (Button)sender;
            mathOperator = button.Text;
            lastKeyPressed = button.Text;
           
            lblCurrentOperation.Text = double.Parse(lblScreen.Text) + " " + mathOperator;

            EqualsButtonPressed = false;

        }
        // end operatorButton_Click 

        private void numberButton_Click(object sender, EventArgs e)
        {
            string op = lblCurrentOperation.Text.ToString();
            //double n;
            //bool isNumeric = double.TryParse(lastKeyPressed, out n);

            Button button = (Button)sender;

            // If you just pressed the "=" button and you're entering a new number, then it becomes a new operation. Let's start over.
            if(EqualsButtonPressed)
            {
                ClearFields();

                lblScreen.Text = "";

                lblScreen.Text += button.Text;
            }
            else if ((lblScreen.Text != "0" && lblScreen.Text != "N/A") && !(op.EndsWith("+") || op.EndsWith("-") || op.EndsWith("*") || op.EndsWith("/")))
            {
                lblScreen.Text += button.Text;
            }
            // If the screen is showing 0 or you divided a number by 0 (resulting in N/A)
            else if (lblScreen.Text == "0" || lblScreen.Text == "N/A" || lastKeyPressed.EndsWith("+") || lastKeyPressed.EndsWith("-") || lastKeyPressed.EndsWith("*") || lastKeyPressed.EndsWith("/"))
            {
                lblScreen.Text = "";

                lblScreen.Text += button.Text;
            }
            else
            {
                lblScreen.Text += button.Text;
                // do nothing
            }

            lastValueEntered = double.Parse(lblScreen.Text);
            lastKeyPressed = button.Text;
            EqualsButtonPressed = false;
                        
        }
        // end numberButton_Click

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblScreen.Text = "0";

            ClearFields();
        }

        private void ClearFields()
        {
            //lblScreen.Text = "0";
            lblCurrentOperation.Text = "";
            lastValueEntered = 0;
            result = 0;
            mathOperator = "";
            
            EqualsButtonPressed = false;
            
        }

        private void btnBackspace_Click(object sender, EventArgs e)
        {
            if (lblScreen.Text == "0" || lblScreen.Text == "")
            {
                ClearFields();
            }
            else
            {
                lblScreen.Text = lblScreen.Text.Remove(lblScreen.Text.Length - 1);
            }            
        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            UpdateResult();

            EqualsButtonPressed = true;
        }

        private void btnDecimal_Click(object sender, EventArgs e)
        {
            // prevent user from entering more than 1 decimal
            if (!(lastValueEntered.ToString()).Contains("."))
            {
                Button button = (Button)sender;
                lblScreen.Text += button.Text;

                lastValueEntered = double.Parse(lblScreen.Text);
            }
            else
            {
                // do nothing
            }
        }


        // Set Form.KeyPreview to True for event handler to be called.
        void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // handles 0-9, math operators, backspace and Enter buttons
            if ((e.KeyChar >= 42 && e.KeyChar <= 57) || (e.KeyChar == 8) || (e.KeyChar == 13))
            {
                //MessageBox.Show("Button pressed: " + e.KeyChar.ToString());

                switch (e.KeyChar)
                {
                    case (char)48:
                        btnZero.PerformClick();
                        break;
                    case (char)49:
                        btnOne.PerformClick();
                        break;
                    case (char)50:
                        btnTwo.PerformClick();
                        break;
                    case (char)51:
                        btnThree.PerformClick();
                        break;
                    case (char)52:
                        btnFour.PerformClick();
                        break;
                    case (char)53:
                        btnFive.PerformClick();
                        break;
                    case (char)54:
                        btnSix.PerformClick();
                        break;
                    case (char)55:
                        btnSeven.PerformClick();
                        break;
                    case (char)56:
                        btnEight.PerformClick();
                        break;
                    case (char)57:
                        btnNine.PerformClick();
                        break;
                    case (char)8:
                        btnBackspace.PerformClick();
                        break;
                    case (char)42:
                        btnMultiply.PerformClick();
                        break;
                    case (char)43:
                        btnAdd.PerformClick();
                        break;
                    case (char)45:
                        btnSubtract.PerformClick();
                        break;
                    case (char)46:
                        btnDecimal.PerformClick();
                        break;
                    case (char)47:
                        btnDivide.PerformClick();
                        break;
                }
            }
        }
        // end of key press event handler
    }
}
