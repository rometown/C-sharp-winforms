﻿// Author: Millora, Romeo
// Assignment 02
// Feb. 1, 2016

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics; // allows you to write to the debug window

namespace MyClassLibrary
{
    public class MyCalcLibrary
    {

        public MyCalcLibrary()
        {

        }


        public double Add(double x, double y)
        {
            return x + y;
        }

        public double Subtract(double x, double y)
        {
            return x - y;
        }

        public double Multiply(double x, double y)
        {
            return x * y;
        }

        public double Divide(double x, double y)
        {
            return x / y;
        }
    }
}
