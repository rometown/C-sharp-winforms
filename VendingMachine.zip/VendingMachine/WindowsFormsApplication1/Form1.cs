﻿// Exercise 7 - due Nov 30
// Author: Millora, Romeo

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LiveCodeLesson;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        //Decimal sum = 0;

        // change these to private
        PurchasePrice PP = new PurchasePrice(0.35M);
        CanRack CR = new CanRack();
        //CoinBox CB = new CoinBox();
        CoinBox mainCB = new CoinBox(new List<Coin> {
                new Coin(Coin.Denomination.QUARTER), new Coin(Coin.Denomination.DIME),
                new Coin(Coin.Denomination.NICKEL), new Coin(Coin.Denomination.QUARTER),
                new Coin(Coin.Denomination.QUARTER), new Coin(Coin.Denomination.DIME) });
        CoinBox tempCB = new CoinBox();
                
                
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblSodaPrice.Text = PP.DecimalPrice.ToString("C");
            
            refreshVendTab();
            refreshServiceTab();

            // For debugging
            groupBox1.Visible = false;            
            
        }

                
        private void btnNickel_Click(object sender, EventArgs e)
        {
            Coin coinInserted = null;

            coinInserted = new Coin(Coin.Denomination.NICKEL);

            tempCB.Deposit(coinInserted);
            lblAmountInserted.Text = tempCB.ValueOf.ToString("C");
        }

        private void btnDime_Click(object sender, EventArgs e)
        {
            Coin coinInserted = null;

            coinInserted = new Coin(Coin.Denomination.DIME);

            tempCB.Deposit(coinInserted);
            lblAmountInserted.Text = tempCB.ValueOf.ToString("C");
        }

        private void btnQuarter_Click(object sender, EventArgs e)
        {
            Coin coinInserted = null;
            coinInserted = new Coin(Coin.Denomination.QUARTER);

            tempCB.Deposit(coinInserted);
            lblAmountInserted.Text = tempCB.ValueOf.ToString("C");
        }

        private void btnHalfdollar_Click(object sender, EventArgs e)
        {
            Coin coinInserted = null;
            coinInserted = new Coin(Coin.Denomination.HALFDOLLAR);

            tempCB.Deposit(coinInserted);
            lblAmountInserted.Text = tempCB.ValueOf.ToString("C");
        }

        private void lblAmountInserted_TextChanged(object sender, EventArgs e)
        {
            refreshVendTab();
        }

        private void refreshVendTab()
        {
            lblAmountInserted.Text = tempCB.ValueOf.ToString("C");

            if (mainCB.CanMakeChange)
            {
                lblExactChange.Visible = false;
            }
            else
            {
                lblExactChange.Visible = true;
            }


            //Refresh Return Money button
            if (tempCB.ValueOf > 0M)
            {
                btnReturnMoney.Enabled = true;

                // For debugging
                lblTempCBValueOf.Text = tempCB.ValueOf.ToString("C");
            }
            else
            {
                btnReturnMoney.Enabled = false;
            }


            //Refresh button texts
            if (CR.IsEmpty(Flavor.REGULAR))
            {
                btnRegular.Text = "Empty";
            }
            else
            {
                btnRegular.Text = "Regular";
            }

            if (CR.IsEmpty(Flavor.ORANGE))
            {
                btnOrange.Text = "Empty";
            }
            else
            {
                btnOrange.Text = "Orange";
            }

            if (CR.IsEmpty(Flavor.LEMON))
            {
                btnLemon.Text = "Empty";
            }
            else
            {
                btnLemon.Text = "Lemon";
            }


            // Update buttons for all flavors if not empty
            if (tempCB.ValueOf >= PP.DecimalPrice)
            {
                if (!CR.IsEmpty(Flavor.REGULAR))
                {
                    btnRegular.Enabled = true;
                }
                else { /* do nothing */ }

                if (!CR.IsEmpty(Flavor.ORANGE))
                {
                    btnOrange.Enabled = true;
                }
                else { /* do nothing */ }

                if (!CR.IsEmpty(Flavor.LEMON))
                {
                    btnLemon.Enabled = true;
                }
                else { /* do nothing */ }
            }
            else
            {
                btnRegular.Enabled = btnOrange.Enabled = btnLemon.Enabled = false;
            }

            //For debugging
            lblCoinBoxValueOf.Text = mainCB.ValueOf.ToString("C");
            lblRegularCount.Text = CR.RegularCount.ToString();
            lblOrangeCount.Text = CR.OrangeCount.ToString();
            lblLemonCount.Text = CR.LemonCount.ToString();

        }

        private void refreshServiceTab()
        {
            // Clear all tables before refreshing tab
            listView1.Items.Clear();
            listView2.Items.Clear();
            listView3.Items.Clear();


            // ListView for Can Rack
            ListViewItem itemCanRack = new ListViewItem("Regular");
            itemCanRack.SubItems.Add(CR.RegularCount.ToString());
            listView1.Items.Add(itemCanRack);

            itemCanRack = new ListViewItem("Orange");
            itemCanRack.SubItems.Add(CR.OrangeCount.ToString());
            listView1.Items.Add(itemCanRack);

            itemCanRack = new ListViewItem("Lemon");
            itemCanRack.SubItems.Add(CR.LemonCount.ToString());
            listView1.Items.Add(itemCanRack);


            // ListView for Coin Box
            ListViewItem itemCoinBox = new ListViewItem("SLUG");
            itemCoinBox.SubItems.Add(mainCB.SlugCount.ToString());
            listView2.Items.Add(itemCoinBox);

            itemCoinBox = new ListViewItem("NICKEL");
            itemCoinBox.SubItems.Add(mainCB.NickelCount.ToString());
            listView2.Items.Add(itemCoinBox);

            itemCoinBox = new ListViewItem("DIME");
            itemCoinBox.SubItems.Add(mainCB.DimeCount.ToString());
            listView2.Items.Add(itemCoinBox);

            itemCoinBox = new ListViewItem("QUARTER");
            itemCoinBox.SubItems.Add(mainCB.QuarterCount.ToString());
            listView2.Items.Add(itemCoinBox);

            itemCoinBox = new ListViewItem("HALFDOLLAR");
            itemCoinBox.SubItems.Add(mainCB.HalfDollarCount.ToString());
            listView2.Items.Add(itemCoinBox);


            // ListView for Temp Coin Box
            ListViewItem itemTempCoinBox = new ListViewItem("SLUG");
            itemTempCoinBox.SubItems.Add(tempCB.SlugCount.ToString());
            listView3.Items.Add(itemTempCoinBox);

            itemTempCoinBox = new ListViewItem("NICKEL");
            itemTempCoinBox.SubItems.Add(tempCB.NickelCount.ToString());
            listView3.Items.Add(itemTempCoinBox);

            itemTempCoinBox = new ListViewItem("DIME");
            itemTempCoinBox.SubItems.Add(tempCB.DimeCount.ToString());
            listView3.Items.Add(itemTempCoinBox);

            itemTempCoinBox = new ListViewItem("QUARTER");
            itemTempCoinBox.SubItems.Add(tempCB.QuarterCount.ToString());
            listView3.Items.Add(itemTempCoinBox);

            itemTempCoinBox = new ListViewItem("HALFDOLLAR");
            itemTempCoinBox.SubItems.Add(tempCB.HalfDollarCount.ToString());
            listView3.Items.Add(itemTempCoinBox);


            lblCoinBoxTotal.Text = "Coin Box Total: " + mainCB.ValueOf.ToString("C");
            lblTempCoinBoxTotal.Text = "Temp Coin Box Total: " + tempCB.ValueOf.ToString("C");
        }

        private void TabControl1_SelectedIndexChanged(Object sender, EventArgs e)
        {
            refreshVendTab();
            refreshServiceTab();
        }

        private void btnRegular_Click(object sender, EventArgs e)
        {
            DispenseSoda(Flavor.REGULAR);            
        }

        private void btnOrange_Click(object sender, EventArgs e)
        {
            DispenseSoda(Flavor.ORANGE); 
        }

        private void btnLemon_Click(object sender, EventArgs e)
        {
            DispenseSoda(Flavor.LEMON);
        }

        private void btnReturnMoney_Click(object sender, EventArgs e)
        {
            lblChange.Text = tempCB.ValueOf.ToString("C");

            //Empty tempCB
            tempCB.Withdraw(tempCB.ValueOf);

            refreshVendTab();
        }

        private void DispenseSoda(Flavor dispenseFlavor)
        {
            decimal changeAmount = 0M;

            changeAmount = tempCB.ValueOf - PP.DecimalPrice;

            CR.RemoveACanOf(dispenseFlavor);
            MessageBox.Show("Thanks! Enjoy your " + dispenseFlavor + " soda!");

            tempCB.Transfer(mainCB);

            if ((changeAmount > 0M) && mainCB.CanMakeChange)
            {
                mainCB.Withdraw(changeAmount);
                lblChange.Text = (changeAmount).ToString("C");
            }
            else
            {
                lblChange.Text = "$0.00";
            }

            refreshVendTab();
        }

        private void btnRefillCanRack_Click(object sender, EventArgs e)
        {
            CR.FillTheCanRack();

            refreshServiceTab();
        }

        private void btnEmptyCoinBox_Click(object sender, EventArgs e)
        {
            decimal withdrawAmount = 0M;
            withdrawAmount = mainCB.ValueOf;

            MessageBox.Show("Total amount withdrawn: " + withdrawAmount.ToString("C"));

            mainCB.Withdraw(withdrawAmount);

            refreshServiceTab();
        }

        private void btnEmptyTempCoinBox_Click(object sender, EventArgs e)
        {
            decimal withdrawAmount = 0M;
            withdrawAmount = tempCB.ValueOf;

            MessageBox.Show("Total amount withdrawn: " + withdrawAmount.ToString("C"));

            tempCB.Withdraw(withdrawAmount);

            refreshServiceTab();
        }

    }
}
