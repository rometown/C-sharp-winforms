﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.btnRegular = new System.Windows.Forms.Button();
            this.btnOrange = new System.Windows.Forms.Button();
            this.btnLemon = new System.Windows.Forms.Button();
            this.btnNickel = new System.Windows.Forms.Button();
            this.btnDime = new System.Windows.Forms.Button();
            this.btnQuarter = new System.Windows.Forms.Button();
            this.btnHalfdollar = new System.Windows.Forms.Button();
            this.btnReturnMoney = new System.Windows.Forms.Button();
            this.lblExactChange = new System.Windows.Forms.Label();
            this.lblSodaPrice = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblAmountInserted = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblChange = new System.Windows.Forms.Label();
            this.lblCoinBoxValueOf = new System.Windows.Forms.Label();
            this.lblCoinBox = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTempCBValueOf = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblLemonCount = new System.Windows.Forms.Label();
            this.lblOrangeCount = new System.Windows.Forms.Label();
            this.lblRegularCount = new System.Windows.Forms.Label();
            this.lblLemon = new System.Windows.Forms.Label();
            this.lblOrange = new System.Windows.Forms.Label();
            this.lblRegular = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnEmptyTempCoinBox = new System.Windows.Forms.Button();
            this.lblTempCoinBoxTotal = new System.Windows.Forms.Label();
            this.listView3 = new System.Windows.Forms.ListView();
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lblCoinBoxTotal = new System.Windows.Forms.Label();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnEmptyCoinBox = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnRefillCanRack = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(72, 51);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Insert Coins";
            // 
            // btnRegular
            // 
            this.btnRegular.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegular.Location = new System.Drawing.Point(474, 210);
            this.btnRegular.Margin = new System.Windows.Forms.Padding(2);
            this.btnRegular.Name = "btnRegular";
            this.btnRegular.Size = new System.Drawing.Size(86, 28);
            this.btnRegular.TabIndex = 4;
            this.btnRegular.Text = "Regular";
            this.btnRegular.UseVisualStyleBackColor = true;
            this.btnRegular.Click += new System.EventHandler(this.btnRegular_Click);
            // 
            // btnOrange
            // 
            this.btnOrange.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOrange.Location = new System.Drawing.Point(564, 210);
            this.btnOrange.Margin = new System.Windows.Forms.Padding(2);
            this.btnOrange.Name = "btnOrange";
            this.btnOrange.Size = new System.Drawing.Size(85, 28);
            this.btnOrange.TabIndex = 5;
            this.btnOrange.Text = "Orange";
            this.btnOrange.UseVisualStyleBackColor = true;
            this.btnOrange.Click += new System.EventHandler(this.btnOrange_Click);
            // 
            // btnLemon
            // 
            this.btnLemon.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLemon.Location = new System.Drawing.Point(653, 210);
            this.btnLemon.Margin = new System.Windows.Forms.Padding(2);
            this.btnLemon.Name = "btnLemon";
            this.btnLemon.Size = new System.Drawing.Size(86, 28);
            this.btnLemon.TabIndex = 6;
            this.btnLemon.Text = "Lemon";
            this.btnLemon.UseVisualStyleBackColor = true;
            this.btnLemon.Click += new System.EventHandler(this.btnLemon_Click);
            // 
            // btnNickel
            // 
            this.btnNickel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNickel.Location = new System.Drawing.Point(171, 132);
            this.btnNickel.Margin = new System.Windows.Forms.Padding(2);
            this.btnNickel.Name = "btnNickel";
            this.btnNickel.Size = new System.Drawing.Size(88, 28);
            this.btnNickel.TabIndex = 7;
            this.btnNickel.Text = "Nickel";
            this.btnNickel.UseVisualStyleBackColor = true;
            this.btnNickel.Click += new System.EventHandler(this.btnNickel_Click);
            // 
            // btnDime
            // 
            this.btnDime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDime.Location = new System.Drawing.Point(171, 164);
            this.btnDime.Margin = new System.Windows.Forms.Padding(2);
            this.btnDime.Name = "btnDime";
            this.btnDime.Size = new System.Drawing.Size(88, 28);
            this.btnDime.TabIndex = 8;
            this.btnDime.Text = "Dime";
            this.btnDime.UseVisualStyleBackColor = true;
            this.btnDime.Click += new System.EventHandler(this.btnDime_Click);
            // 
            // btnQuarter
            // 
            this.btnQuarter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuarter.Location = new System.Drawing.Point(171, 196);
            this.btnQuarter.Margin = new System.Windows.Forms.Padding(2);
            this.btnQuarter.Name = "btnQuarter";
            this.btnQuarter.Size = new System.Drawing.Size(88, 28);
            this.btnQuarter.TabIndex = 9;
            this.btnQuarter.Text = "Quarter";
            this.btnQuarter.UseVisualStyleBackColor = true;
            this.btnQuarter.Click += new System.EventHandler(this.btnQuarter_Click);
            // 
            // btnHalfdollar
            // 
            this.btnHalfdollar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHalfdollar.Location = new System.Drawing.Point(171, 228);
            this.btnHalfdollar.Margin = new System.Windows.Forms.Padding(2);
            this.btnHalfdollar.Name = "btnHalfdollar";
            this.btnHalfdollar.Size = new System.Drawing.Size(88, 28);
            this.btnHalfdollar.TabIndex = 10;
            this.btnHalfdollar.Text = "Halfdollar";
            this.btnHalfdollar.UseVisualStyleBackColor = true;
            this.btnHalfdollar.Click += new System.EventHandler(this.btnHalfdollar_Click);
            // 
            // btnReturnMoney
            // 
            this.btnReturnMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReturnMoney.Location = new System.Drawing.Point(266, 91);
            this.btnReturnMoney.Margin = new System.Windows.Forms.Padding(2);
            this.btnReturnMoney.Name = "btnReturnMoney";
            this.btnReturnMoney.Size = new System.Drawing.Size(122, 28);
            this.btnReturnMoney.TabIndex = 11;
            this.btnReturnMoney.Text = "Return Money";
            this.btnReturnMoney.UseVisualStyleBackColor = true;
            this.btnReturnMoney.Click += new System.EventHandler(this.btnReturnMoney_Click);
            // 
            // lblExactChange
            // 
            this.lblExactChange.AutoSize = true;
            this.lblExactChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExactChange.ForeColor = System.Drawing.Color.Red;
            this.lblExactChange.Location = new System.Drawing.Point(263, 47);
            this.lblExactChange.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblExactChange.Name = "lblExactChange";
            this.lblExactChange.Size = new System.Drawing.Size(125, 34);
            this.lblExactChange.TabIndex = 12;
            this.lblExactChange.Text = "Use exact change.\r\nNo change given.";
            // 
            // lblSodaPrice
            // 
            this.lblSodaPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSodaPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSodaPrice.Location = new System.Drawing.Point(189, 47);
            this.lblSodaPrice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSodaPrice.Name = "lblSodaPrice";
            this.lblSodaPrice.Size = new System.Drawing.Size(70, 28);
            this.lblSodaPrice.TabIndex = 15;
            this.lblSodaPrice.Text = "$0.35";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(45, 95);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 20);
            this.label6.TabIndex = 16;
            this.label6.Text = "Amount Inserted";
            // 
            // lblAmountInserted
            // 
            this.lblAmountInserted.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAmountInserted.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmountInserted.Location = new System.Drawing.Point(189, 91);
            this.lblAmountInserted.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAmountInserted.Name = "lblAmountInserted";
            this.lblAmountInserted.Size = new System.Drawing.Size(70, 28);
            this.lblAmountInserted.TabIndex = 17;
            this.lblAmountInserted.Text = "$ --";
            this.lblAmountInserted.TextChanged += new System.EventHandler(this.lblAmountInserted_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(101, 293);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 20);
            this.label3.TabIndex = 20;
            this.label3.Text = "Change";
            // 
            // lblChange
            // 
            this.lblChange.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChange.Location = new System.Drawing.Point(189, 289);
            this.lblChange.Name = "lblChange";
            this.lblChange.Size = new System.Drawing.Size(70, 28);
            this.lblChange.TabIndex = 21;
            this.lblChange.Text = "$ --";
            // 
            // lblCoinBoxValueOf
            // 
            this.lblCoinBoxValueOf.AutoSize = true;
            this.lblCoinBoxValueOf.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCoinBoxValueOf.Location = new System.Drawing.Point(111, 19);
            this.lblCoinBoxValueOf.Name = "lblCoinBoxValueOf";
            this.lblCoinBoxValueOf.Size = new System.Drawing.Size(30, 17);
            this.lblCoinBoxValueOf.TabIndex = 24;
            this.lblCoinBoxValueOf.Text = "$ --";
            // 
            // lblCoinBox
            // 
            this.lblCoinBox.AutoSize = true;
            this.lblCoinBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCoinBox.Location = new System.Drawing.Point(6, 19);
            this.lblCoinBox.Name = "lblCoinBox";
            this.lblCoinBox.Size = new System.Drawing.Size(101, 17);
            this.lblCoinBox.TabIndex = 23;
            this.lblCoinBox.Text = "CoinBox value:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 17);
            this.label4.TabIndex = 25;
            this.label4.Text = "tempCB value:";
            // 
            // lblTempCBValueOf
            // 
            this.lblTempCBValueOf.AutoSize = true;
            this.lblTempCBValueOf.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTempCBValueOf.Location = new System.Drawing.Point(111, 36);
            this.lblTempCBValueOf.Name = "lblTempCBValueOf";
            this.lblTempCBValueOf.Size = new System.Drawing.Size(30, 17);
            this.lblTempCBValueOf.TabIndex = 26;
            this.lblTempCBValueOf.Text = "$ --";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblLemonCount);
            this.groupBox1.Controls.Add(this.lblOrangeCount);
            this.groupBox1.Controls.Add(this.lblRegularCount);
            this.groupBox1.Controls.Add(this.lblLemon);
            this.groupBox1.Controls.Add(this.lblOrange);
            this.groupBox1.Controls.Add(this.lblRegular);
            this.groupBox1.Controls.Add(this.lblCoinBox);
            this.groupBox1.Controls.Add(this.lblTempCBValueOf);
            this.groupBox1.Controls.Add(this.lblCoinBoxValueOf);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(474, 275);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(179, 107);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "For Debugging";
            // 
            // lblLemonCount
            // 
            this.lblLemonCount.AutoSize = true;
            this.lblLemonCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLemonCount.Location = new System.Drawing.Point(111, 87);
            this.lblLemonCount.Name = "lblLemonCount";
            this.lblLemonCount.Size = new System.Drawing.Size(18, 17);
            this.lblLemonCount.TabIndex = 34;
            this.lblLemonCount.Text = "--";
            // 
            // lblOrangeCount
            // 
            this.lblOrangeCount.AutoSize = true;
            this.lblOrangeCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrangeCount.Location = new System.Drawing.Point(111, 70);
            this.lblOrangeCount.Name = "lblOrangeCount";
            this.lblOrangeCount.Size = new System.Drawing.Size(18, 17);
            this.lblOrangeCount.TabIndex = 33;
            this.lblOrangeCount.Text = "--";
            // 
            // lblRegularCount
            // 
            this.lblRegularCount.AutoSize = true;
            this.lblRegularCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegularCount.Location = new System.Drawing.Point(111, 53);
            this.lblRegularCount.Name = "lblRegularCount";
            this.lblRegularCount.Size = new System.Drawing.Size(18, 17);
            this.lblRegularCount.TabIndex = 32;
            this.lblRegularCount.Text = "--";
            // 
            // lblLemon
            // 
            this.lblLemon.AutoSize = true;
            this.lblLemon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLemon.Location = new System.Drawing.Point(6, 87);
            this.lblLemon.Name = "lblLemon";
            this.lblLemon.Size = new System.Drawing.Size(51, 17);
            this.lblLemon.TabIndex = 31;
            this.lblLemon.Text = "Lemon";
            // 
            // lblOrange
            // 
            this.lblOrange.AutoSize = true;
            this.lblOrange.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrange.Location = new System.Drawing.Point(6, 70);
            this.lblOrange.Name = "lblOrange";
            this.lblOrange.Size = new System.Drawing.Size(56, 17);
            this.lblOrange.TabIndex = 30;
            this.lblOrange.Text = "Orange";
            // 
            // lblRegular
            // 
            this.lblRegular.AutoSize = true;
            this.lblRegular.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegular.Location = new System.Drawing.Point(6, 53);
            this.lblRegular.Name = "lblRegular";
            this.lblRegular.Size = new System.Drawing.Size(58, 17);
            this.lblRegular.TabIndex = 29;
            this.lblRegular.Text = "Regular";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(474, 56);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(86, 150);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(564, 56);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(86, 150);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 30;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(654, 56);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(86, 150);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 31;
            this.pictureBox3.TabStop = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(869, 419);
            this.tabControl1.TabIndex = 32;
            this.tabControl1.Click += new System.EventHandler(this.TabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pictureBox4);
            this.tabPage1.Controls.Add(this.btnNickel);
            this.tabPage1.Controls.Add(this.pictureBox3);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.btnRegular);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.btnOrange);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.btnLemon);
            this.tabPage1.Controls.Add(this.lblChange);
            this.tabPage1.Controls.Add(this.btnDime);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.btnQuarter);
            this.tabPage1.Controls.Add(this.btnHalfdollar);
            this.tabPage1.Controls.Add(this.lblAmountInserted);
            this.tabPage1.Controls.Add(this.btnReturnMoney);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.lblExactChange);
            this.tabPage1.Controls.Add(this.lblSodaPrice);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(861, 393);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Vend";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(861, 393);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Service";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnEmptyTempCoinBox);
            this.groupBox4.Controls.Add(this.lblTempCoinBoxTotal);
            this.groupBox4.Controls.Add(this.listView3);
            this.groupBox4.Location = new System.Drawing.Point(510, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(200, 247);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Temp Coin Box";
            // 
            // btnEmptyTempCoinBox
            // 
            this.btnEmptyTempCoinBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmptyTempCoinBox.Location = new System.Drawing.Point(6, 213);
            this.btnEmptyTempCoinBox.Name = "btnEmptyTempCoinBox";
            this.btnEmptyTempCoinBox.Size = new System.Drawing.Size(136, 28);
            this.btnEmptyTempCoinBox.TabIndex = 9;
            this.btnEmptyTempCoinBox.Text = "EMPTY";
            this.btnEmptyTempCoinBox.UseVisualStyleBackColor = true;
            this.btnEmptyTempCoinBox.Click += new System.EventHandler(this.btnEmptyTempCoinBox_Click);
            // 
            // lblTempCoinBoxTotal
            // 
            this.lblTempCoinBoxTotal.AutoSize = true;
            this.lblTempCoinBoxTotal.Location = new System.Drawing.Point(6, 183);
            this.lblTempCoinBoxTotal.Name = "lblTempCoinBoxTotal";
            this.lblTempCoinBoxTotal.Size = new System.Drawing.Size(35, 13);
            this.lblTempCoinBoxTotal.TabIndex = 4;
            this.lblTempCoinBoxTotal.Text = "label2";
            // 
            // listView3
            // 
            this.listView3.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader5,
            this.columnHeader6});
            this.listView3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView3.GridLines = true;
            this.listView3.Location = new System.Drawing.Point(6, 19);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(188, 161);
            this.listView3.TabIndex = 3;
            this.listView3.UseCompatibleStateImageBehavior = false;
            this.listView3.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Denomination";
            this.columnHeader5.Width = 85;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Coin Count";
            this.columnHeader6.Width = 80;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lblCoinBoxTotal);
            this.groupBox3.Controls.Add(this.listView2);
            this.groupBox3.Controls.Add(this.btnEmptyCoinBox);
            this.groupBox3.Location = new System.Drawing.Point(256, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 247);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Coin Box";
            // 
            // lblCoinBoxTotal
            // 
            this.lblCoinBoxTotal.AutoSize = true;
            this.lblCoinBoxTotal.Location = new System.Drawing.Point(6, 183);
            this.lblCoinBoxTotal.Name = "lblCoinBoxTotal";
            this.lblCoinBoxTotal.Size = new System.Drawing.Size(35, 13);
            this.lblCoinBoxTotal.TabIndex = 5;
            this.lblCoinBoxTotal.Text = "label2";
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.listView2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView2.GridLines = true;
            this.listView2.Location = new System.Drawing.Point(6, 19);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(188, 161);
            this.listView2.TabIndex = 2;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Denomination";
            this.columnHeader3.Width = 85;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Coin Count";
            this.columnHeader4.Width = 80;
            // 
            // btnEmptyCoinBox
            // 
            this.btnEmptyCoinBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmptyCoinBox.Location = new System.Drawing.Point(6, 213);
            this.btnEmptyCoinBox.Name = "btnEmptyCoinBox";
            this.btnEmptyCoinBox.Size = new System.Drawing.Size(136, 28);
            this.btnEmptyCoinBox.TabIndex = 4;
            this.btnEmptyCoinBox.Text = "EMPTY";
            this.btnEmptyCoinBox.UseVisualStyleBackColor = true;
            this.btnEmptyCoinBox.Click += new System.EventHandler(this.btnEmptyCoinBox_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.listView1);
            this.groupBox2.Controls.Add(this.btnRefillCanRack);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 247);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Can Rack";
            // 
            // listView1
            // 
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(6, 19);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(188, 161);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Flavor";
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Quantity";
            // 
            // btnRefillCanRack
            // 
            this.btnRefillCanRack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRefillCanRack.Location = new System.Drawing.Point(6, 213);
            this.btnRefillCanRack.Name = "btnRefillCanRack";
            this.btnRefillCanRack.Size = new System.Drawing.Size(136, 28);
            this.btnRefillCanRack.TabIndex = 1;
            this.btnRefillCanRack.Text = "Refill Can Rack";
            this.btnRefillCanRack.UseVisualStyleBackColor = true;
            this.btnRefillCanRack.Click += new System.EventHandler(this.btnRefillCanRack_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(262, 132);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(126, 118);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 32;
            this.pictureBox4.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(893, 441);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ShowIcon = false;
            this.Text = "Romeo Millora - Vending Machine Application";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRegular;
        private System.Windows.Forms.Button btnOrange;
        private System.Windows.Forms.Button btnLemon;
        private System.Windows.Forms.Button btnNickel;
        private System.Windows.Forms.Button btnDime;
        private System.Windows.Forms.Button btnQuarter;
        private System.Windows.Forms.Button btnHalfdollar;
        private System.Windows.Forms.Button btnReturnMoney;
        private System.Windows.Forms.Label lblExactChange;
        private System.Windows.Forms.Label lblSodaPrice;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblAmountInserted;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblChange;
        private System.Windows.Forms.Label lblCoinBoxValueOf;
        private System.Windows.Forms.Label lblCoinBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTempCBValueOf;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblLemonCount;
        private System.Windows.Forms.Label lblOrangeCount;
        private System.Windows.Forms.Label lblRegularCount;
        private System.Windows.Forms.Label lblLemon;
        private System.Windows.Forms.Label lblOrange;
        private System.Windows.Forms.Label lblRegular;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Button btnRefillCanRack;
        private System.Windows.Forms.Button btnEmptyCoinBox;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblCoinBoxTotal;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListView listView3;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.Button btnEmptyTempCoinBox;
        private System.Windows.Forms.Label lblTempCoinBoxTotal;
        private System.Windows.Forms.PictureBox pictureBox4;
    }
}

