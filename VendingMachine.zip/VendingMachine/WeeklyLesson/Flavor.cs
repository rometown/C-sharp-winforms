﻿// Exercise 7 - due Nov 30
// Author: Millora, Romeo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace LiveCodeLesson
{
    public enum Flavor { REGULAR = 0, ORANGE = 1, LEMON = 2 }


    //Exercise 5.1 - create FlavorOps class that will contain operations on the type Flavor
    class FlavorOps
    {
        private static List<Flavor> _allFlavors = new List<Flavor>();

        // static constructor (see ClassroomExample 1)
        static FlavorOps()
        {
            Debug.WriteLine("Inside FlavorOps() constructor");
            
            foreach (string flavorName in Enum.GetNames(typeof(Flavor)))
            //foreach (var item in FlavorOps.AllFlavors)
            {
                _allFlavors.Add(ToFlavor(flavorName));
            }            
        }

        //method to convert a string value into an enumeral
        public static Flavor ToFlavor(string FlavorName)
        {
            Flavor flavorEnum;

            if (Enum.IsDefined(typeof(Flavor), FlavorName))
            {
                flavorEnum = (Flavor)Enum.Parse(typeof(Flavor), FlavorName);

                return flavorEnum;
            }
            else
            {
                Debug.WriteLine("Error: Unable to convert unknown flavor {0}", FlavorName);

                return 0;
            }
        }

        //property to return a List<Flavor> of all of the Varieties
        public static List<Flavor> AllFlavors
        {
            get
            {
                return _allFlavors;
            }
        }

    }

}
