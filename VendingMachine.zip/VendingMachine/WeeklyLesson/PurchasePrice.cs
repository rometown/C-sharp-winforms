﻿// Exercise 7 - due Nov 30
// Author: Millora, Romeo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiveCodeLesson
{
    // This class represents the purchase price of something.
    // In our software project, we will use it to represent the price of
    // one can of soda.
    public class PurchasePrice
    {
        // Exercise 3.1 - change to decimal
        // This property gets and sets the value of purchase price.
        decimal _price = 0M;

        // This constructor sets the purchase price to zero
        public PurchasePrice()
        {
            _price = 0M;
        }

        // Exercise 3.1 - change parameter of constructor to decimal
        // This constructor allows a new purchase price to be set by the user
        // Obsolete. Add compiler error warning.
        [Obsolete("Use the decimal version of this constructor instead", false)]
        public PurchasePrice(int initialPrice)
        {
            _price = ((decimal)initialPrice)/100M;
        }

        // Exercise 3.1 - change parameter of constructor to decimal
        // This constructor allows a new purchase price to be set by the user
        public PurchasePrice(decimal initialPrice)
        {
            _price = initialPrice;
        }


        //  This property gets and sets the value the purchase price.
        [Obsolete("Use the decimal version of this property instead", false)]
        public int Price
        {
            get
            {
                return (int)(_price * 100);
            }
        }

        // Changed the property from "int" to "decimal"
        // If you keep both properties, then you have to rename one because you cannot have 2 properties with the same name.
        public decimal DecimalPrice
        {
            get
            {
                return _price;
            }

        }


    }
}
