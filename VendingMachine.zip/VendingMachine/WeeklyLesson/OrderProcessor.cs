﻿// Exercise 7 - due Nov 30
// Author: Millora, Romeo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiveCodeLesson
{
    class OrderProcessor
    {
        //OrderProcessor sodaorder = new OrderProcessor();

        //create order (args)
        //fulfill order (sodavendingmach, sodaprice)
    }
}
