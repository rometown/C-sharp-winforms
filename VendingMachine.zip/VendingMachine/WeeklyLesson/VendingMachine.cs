﻿// Exercise 7 - due Nov 30
// Author: Millora, Romeo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiveCodeLesson
{
    class VendingMachine
    {
        public VendingMachine()
        {
            //constructor
        }

        public void vendingMain(string[] args, PurchasePrice P, CoinBox CB, CanRack CR)
        {
            string chooseFlavor;
            bool needToChooseFlavor = true;
            bool purchaseAnotherSoda = true; // Used in do-while loop while collecting coins

            Console.WriteLine("Welcome to the .NET C# Soda Vending Machine");
            Console.WriteLine("The price of a soda is {0:C} cents.", P.DecimalPrice);
            Console.WriteLine("\n");            

            Console.WriteLine("Proceeding with vending machine program.");
            Console.WriteLine("\n");                       

            // Allow user to purchase more soda
            do
            {
                if (CollectCoins(P, CB) == true)
                {
                    //User has entered enough coins
                    Console.WriteLine("Choose one of these flavor:");
                    CR.DisplayCanRack();

                    //Continue to ask user if invalid flavor
                    //Also, do not allow user to select an empty flavor
                    while (needToChooseFlavor)
                    {
                        Console.Write("Enter flavor here: ");
                        chooseFlavor = (Convert.ToString(Console.ReadLine())).ToUpper();

                        //if flavor is defined
                        if (Enum.IsDefined(typeof(Flavor), chooseFlavor))
                        {
                            //if flavor is empty
                            if (CR.IsEmpty((Flavor)Enum.Parse(typeof(Flavor), chooseFlavor)))
                            {
                                Console.WriteLine("We are out of {0} flavor. Please type another flavor.", chooseFlavor);
                            }
                            //Soda flavor is available. Subtract from inventory and dispense soda to user
                            else
                            {
                                CR.RemoveACanOf((Flavor)Enum.Parse(typeof(Flavor), chooseFlavor));
                                Console.WriteLine("Thank you. Enjoy your {0} soda!\n", chooseFlavor);

                                //get out of while loop
                                needToChooseFlavor = false;
                            }
                        }
                        //no, flavor is not defined
                        else
                        {
                            Console.WriteLine("\"{0}\" is not a valid enum flavor. Please enter a valid flavor name.", chooseFlavor);
                        }
                    }
                }                

                Console.Write("Would you like to try purchasing another soda? Enter Y or N: ");

                // User must enter "N" to exit
                if (Convert.ToString(Console.ReadLine()).ToUpper() == "N")
                {
                    purchaseAnotherSoda = false;
                }

                Console.WriteLine("\n");

            } while (purchaseAnotherSoda);


            CR.DisplayCanRack();

            Console.WriteLine("Run tests on the CanRack() class.");
            testVending(CB, CR);
            
        }


        public void testVending(CoinBox cb, CanRack cr)
        {
                        
            Console.WriteLine("Test removing cans from bins.");
            Console.WriteLine("Removing 1 can of Regular.");
            cr.RemoveACanOf(Flavor.REGULAR);
            Console.WriteLine("Removing 1 can of Orange.");
            cr.RemoveACanOf(Flavor.ORANGE);
            Console.WriteLine("\n");

            cr.DisplayCanRack();

            Console.WriteLine("Empty the can racks.");
            cr.EmptyCanRackOf(Flavor.REGULAR);
            cr.EmptyCanRackOf(Flavor.ORANGE);
            cr.EmptyCanRackOf(Flavor.LEMON);
            Console.WriteLine("\n");

            cr.DisplayCanRack();

            Console.WriteLine("Attempt to remove a can from an empty flavor bin.");
            Console.WriteLine("Remove a can of " + Flavor.REGULAR);
            cr.RemoveACanOf(Flavor.REGULAR);
            Console.WriteLine("\n");

            cr.DisplayCanRack();

            Console.WriteLine("Test adding cans to bins.");
            cr.AddACanOf(Flavor.REGULAR);
            cr.AddACanOf("LEMON"); // calls method with string input   
            Console.WriteLine("\n");

            cr.DisplayCanRack();

            Console.WriteLine("Filling up the can racks.");
            cr.FillTheCanRack();
            Console.WriteLine("\n");

            cr.DisplayCanRack();

            Console.WriteLine("Attempt to add a can of ORANGE soda to a full can rack.");
            cr.AddACanOf(Flavor.ORANGE);    
            Console.WriteLine("\n");

            cr.DisplayCanRack();

        }


        static bool CollectCoins(PurchasePrice p, CoinBox cb)
        {
            string strCoins;
            decimal sum = 0M;
            bool insufficientCoins = true;
            bool continueAddingCoins = true;
                        
            CoinBox tempCB = new CoinBox();

            Console.WriteLine("Please insert {0:C}", p.DecimalPrice);
            Console.Write("Type a variety of coin denominations ( ");

            foreach (string coinName in Enum.GetNames(typeof(Coin.Denomination)))
            {
                Console.Write(coinName + " ");
            }

            Console.WriteLine(").");
            Console.WriteLine("Separate each coin with a comma (e.g. \"nickel\" or \"quarter, dime\")");


            //Collect coins
            //Continue to ask user to enter coins until sum >= $0.35
            while (insufficientCoins && continueAddingCoins)
            {
                Console.Write("Type coin(s) here: ");
                strCoins = (Convert.ToString(Console.ReadLine())).ToUpper();

                //Remove all spaces
                List<char> result = strCoins.ToList();
                result.RemoveAll(c => c == ' ');
                strCoins = new string(result.ToArray());

                //For debugging in console:
                //Console.WriteLine("The string amount you entered is: {0}", strCoins);
                //Cast as (int) to get number value of enum
                //int something = (int)Enum.Parse(typeof(Coin.Denomination), strCoins); // only works with single input

                string[] coinArray = strCoins.Split(',');

                Coin coinInserted = null;

                //Get sum of the coins dropped
                foreach (string word in coinArray)
                {
                    try
                    {
                        coinInserted = new Coin(word);
                    }
                    catch
                    {
                        Console.WriteLine("The coins \"{0}\" was not recognized. Excluding from total.", word);
                    }

                    sum = sum + coinInserted.ValueOf;

                    tempCB.Deposit(coinInserted);

                }           

                Console.WriteLine("Total amount deposited {0:C}", sum);

                //tempCB.DisplayCoinBox();

                if (sum < p.DecimalPrice)
                {
                    //Console.WriteLine("The amount you gave is not enough. Please add more coins.\n");
                    Console.Write("The amount is not enough. Would you like to add more coins?  Enter Y or N: ");

                    // User must enter "N" to exit
                    if (Convert.ToString(Console.ReadLine()).ToUpper() == "N")
                    {
                        continueAddingCoins = false;
                        // withdraw coins for customer

                        return false;
                    }
                }
                else
                {
                    // User has entered enough coins. Choose a flavor.
                    Console.WriteLine("Great! You have entered at least {0:C}.\n", p.DecimalPrice);
                    
                    insufficientCoins = false;
                    continueAddingCoins = false;
                    
                    //transfer change in tempCB to main coinbox
                    tempCB.Transfer(cb);

                    return true;
                }

            } // end while loop

            return false;

        } // end collectCoins

    }
}
