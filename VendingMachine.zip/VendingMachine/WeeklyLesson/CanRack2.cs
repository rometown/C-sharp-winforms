﻿// Exercise 3.1 and 3.2
// Author: Millora, Romeo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiveCodeLesson03
{

    // Exercise 2.2
    // Add CanRack class
    class CanRack2
    {
        // Declare 3 flavors of soda
        private int _regular;
        private int _orange;
        private int _lemon;


        // Constructor for a can rack. The rack starts out full
        public CanRack2()
        {
            Regular = 3;
            Orange = 3;
            Lemon = 3;
        }

        public int Regular
        {
            get { return _regular; }

            private set
            {
                _regular = value;
            }
        }

        public int Orange
        {
            get { return _orange; }

            private set
            {
                _orange = value;
            }
        }

        public int Lemon
        {
            get { return _lemon; }

            private set
            {
                _lemon = value;
            }
        }

        // This method adds a can of the specified flavor to the rack.
        public void AddACanOf(string FlavorOfCanToBeAdded)
        {
            if (FlavorOfCanToBeAdded == "Regular")
            {
                // Check if full
                if (IsFull(FlavorOfCanToBeAdded))
                {
                    Console.WriteLine("Cannot add anymore cans to this bin for this flavor (" + FlavorOfCanToBeAdded + ").");
                }
                else
                    Regular++;
            }
            else if (FlavorOfCanToBeAdded == "Orange")
            {
                // Check if full
                if (IsFull(FlavorOfCanToBeAdded))
                {
                    Console.WriteLine("Cannot add anymore cans to this bin for this flavor (" + FlavorOfCanToBeAdded + ").");
                }
                else
                    Orange++;
            }
            else if (FlavorOfCanToBeAdded == "Lemon")
            {
                // Check if full
                if (IsFull(FlavorOfCanToBeAdded))
                {
                    Console.WriteLine("Cannot add anymore cans to this bin for this flavor (" + FlavorOfCanToBeAdded + ").");
                }
                else
                    Lemon++;
            }
            else
            {
                Console.WriteLine("The flavor you entered was not recognized.");
            }

        }

        // This method will remove a can of the specified flavor from the rack.
        public void RemoveACanOf(string FlavorOfCanToBeRemoved)
        {
            if (FlavorOfCanToBeRemoved == "Regular")
            {
                // Check if empty
                if (IsEmpty(FlavorOfCanToBeRemoved))
                {
                    Console.WriteLine("Cannot remove anymore cans from this bin for this flavor (" + FlavorOfCanToBeRemoved + ").");
                }
                else
                    Regular--;
            }
            else if (FlavorOfCanToBeRemoved == "Orange")
            {
                // Check if empty
                if (IsEmpty(FlavorOfCanToBeRemoved))
                {
                    Console.WriteLine("Cannot remove anymore cans from this bin for this flavor (" + FlavorOfCanToBeRemoved + ").");
                }
                else
                    Orange--;
            }
            else if (FlavorOfCanToBeRemoved == "Lemon")
            {
                // Check if empty
                if (IsEmpty(FlavorOfCanToBeRemoved))
                {
                    Console.WriteLine("Cannot remove anymore cans from this bin for this flavor (" + FlavorOfCanToBeRemoved + ").");
                }
                else
                    Lemon--;
            }
            else
            {
                Console.WriteLine("The flavor you entered was not recognized.");
            }
        }

        // This method will fill the can rack.
        public void FillTheCanRack()
        {
            Regular = 3;
            Orange = 3;
            Lemon = 3;

        }

        // This public void will empty the rack of a given flavor.
        public void EmptyCanRackOf(string FlavorOfBinToBeEmptied)
        {
            if (FlavorOfBinToBeEmptied == "Regular")
            {
                Regular = 0;
            }
            else if (FlavorOfBinToBeEmptied == "Orange")
            {
                Orange = 0;
            }
            else if (FlavorOfBinToBeEmptied == "Lemon")
            {
                Lemon = 0;
            }
            else
            {
                Console.WriteLine("The flavor you entered was not recognized.");
            }

        }

        // OPTIONAL – returns true if the rack is full of a specified flavor
        // false otherwise
        public Boolean IsFull(string FlavorOfBinToCheck)
        {
            int max = 3;

            if (FlavorOfBinToCheck == "Regular")
            {
                if (Regular == max)
                {
                    return true;
                }
                else
                    return false;
            }
            else if (FlavorOfBinToCheck == "Orange")
            {
                if (Orange == max)
                {
                    return true;
                }
                else
                    return false;
            }
            else if (FlavorOfBinToCheck == "Lemon")
            {
                if (Lemon == max)
                {
                    return true;
                }
                else
                    return false;
            }
            else
            {
                Console.WriteLine("The flavor you entered was not recognized.");
                return false;
            }
        }

        // OPTIONAL – return true if the rack is empty of a specified flavor
        // false otherwise
        public Boolean IsEmpty(string FlavorOfBinToCheck)
        {

            if (FlavorOfBinToCheck == "Regular")
            {
                if (Regular == 0)
                {
                    return true;
                }
                else
                    return false;
            }
            else if (FlavorOfBinToCheck == "Orange")
            {
                if (Orange == 0)
                {
                    return true;
                }
                else
                    return false;
            }
            else if (FlavorOfBinToCheck == "Lemon")
            {
                if (Lemon == 0)
                {
                    return true;
                }
                else
                    return false;
            }
            else
            {
                Console.WriteLine("The flavor you entered was not recognized.");
                return false;
            }

        }

    }

}
