﻿// Exercise 7 - due Nov 30
// Author: Millora, Romeo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace LiveCodeLesson
{
    // Exercise 3.2 - Create new Can Rack class and use enum Flavor
    public class CanRack
    {
        // Creates rack[] array of size 3
        // rack[0] is to store # cans of Regular flavor
        // rack[1] is to store # cans of Orange flavor
        // rack[2] is to store # cans of Lemon flavor
        //private int[] rack = new int[Enum.GetValues(typeof(Flavor)).Length]; // replaced by Dictionary in Exercise 5

        // Exercise 5.2 - change from int array above to the generic collection class Dictionary
        //private Dictionary<Flavor, int> rack = null;
        //private Dictionary<Flavor, int> rack = new Dictionary<Flavor, int>();
        private Dictionary<Flavor, int> rack = null;
        
        private const int BINSIZE = 3;
        private const int EMPTYBIN = 0;
        private const int DUMMYARGUMENT = 0;


        // Constructor for a can rack. The rack starts out full.
        public CanRack()
        {
            Debug.WriteLine("Inside CanRack() constructor");

            rack = new Dictionary<Flavor, int>();

            FillTheCanRack();
        }


        // Exercise 4.1 - Add a new method in CanRack
        public void DisplayCanRack()
        {
            Debug.WriteLine("Inside DisplayCanRack()");
            Console.WriteLine("Display rack items.");

            foreach (var item in rack)
            {
                Console.WriteLine("{0} ({1} cans left)", item.Key, item.Value);
            }

            Console.WriteLine("\n");
        }

        
        // This method adds a can of the specified flavor to the rack.
        // Input: Flavor
        public void AddACanOf(Flavor FlavorOfCanToBeAdded)
        {
            AddACanOf(FlavorOfCanToBeAdded.ToString());
        }

        // This method adds a can of the specified flavor to the rack.
        // Input: string value of Flavor
        public void AddACanOf(string FlavorOfCanToBeAdded)
        {
            Debug.WriteLine("Inside AddACanOF(string)");

            if (IsFull(FlavorOfCanToBeAdded))
            {
                Debug.WriteLine("ERROR: Unable to add a can of {0} to a full rack.", FlavorOfCanToBeAdded);
            }
            else
            {
                if (FlavorOps.AllFlavors.Contains(FlavorOps.ToFlavor(FlavorOfCanToBeAdded)))
                {
                    foreach (var item in FlavorOps.AllFlavors)
                    {
                        if (FlavorOfCanToBeAdded == item.ToString())
                            rack[item]++;
                    }
                }
                else
                {
                    Debug.WriteLine("ERROR: Unable to add a can of unknown flavor {0}.", FlavorOfCanToBeAdded, DUMMYARGUMENT);
                }

            }

        }

        // This method will remove a can of the specified flavor from the rack.
        public void RemoveACanOf(Flavor FlavorOfCanToBeRemoved)
        {
            RemoveACanOf(FlavorOfCanToBeRemoved.ToString());
        }

        // This method will remove a can of the specified flavor from the rack.
        public void RemoveACanOf(string FlavorOfCanToBeRemoved)
        {
            Debug.WriteLine("Inside RemoveACanOf()");
            //Console.WriteLine("FlavorOfCanToBeRemoved is {0}", FlavorOfCanToBeRemoved);

            if (IsEmpty(FlavorOfCanToBeRemoved))
            {
                Debug.WriteLine("ERROR: Rack is empty. Unable to remove a can of {0}.", FlavorOfCanToBeRemoved);
            }
            else
            {
                if (FlavorOps.AllFlavors.Contains(FlavorOps.ToFlavor(FlavorOfCanToBeRemoved)))
                {
                    foreach (var item in FlavorOps.AllFlavors)
                    {
                        if (FlavorOfCanToBeRemoved == item.ToString())
                            rack[item]--;
                    }
                }
                else
                {
                    Debug.WriteLine("ERROR: Unable to remove a can of unknown flavor {0}.", FlavorOfCanToBeRemoved, DUMMYARGUMENT);
                }
            }

        }


        // This method will fill the can rack.
        public void FillTheCanRack()
        {
            Debug.WriteLine("Inside FillTheCanRack()");

            foreach (var item in FlavorOps.AllFlavors)
            //for (int i = 0; i < Enum.GetValues(typeof(Flavor)).Length; i++)
            {
                rack[item] = BINSIZE;
            }
        }


        // This public void will empty the rack of a given flavor.
        public void EmptyCanRackOf(Flavor FlavorOfBinToBeEmptied)
        {
            EmptyCanRackOf(FlavorOfBinToBeEmptied.ToString());
        }

        // This public void will empty the rack of a given flavor.
        public void EmptyCanRackOf(string FlavorOfBinToBeEmptied)
        {
            Debug.WriteLine("Inside EmptyCanRackOf)");

            if (FlavorOps.AllFlavors.Contains(FlavorOps.ToFlavor(FlavorOfBinToBeEmptied)))
            {
                foreach (var item in FlavorOps.AllFlavors)
                {
                    if (FlavorOfBinToBeEmptied == item.ToString())
                        rack[item] = EMPTYBIN;
                }
            }
            else
            {
                Debug.WriteLine("ERROR: Unable to empty the bin {0}", FlavorOfBinToBeEmptied, DUMMYARGUMENT);
            }
        }


        public Boolean IsFull(Flavor FlavorOfBinToCheck)
        {
            return IsFull(FlavorOfBinToCheck.ToString());
        }


        public Boolean IsFull(string FlavorOfBinToCheck)
        {
            bool result = false;

            Debug.WriteLine("Inside bool IsFull()");

            if (FlavorOps.AllFlavors.Contains(FlavorOps.ToFlavor(FlavorOfBinToCheck)))
            {
                foreach (var item in FlavorOps.AllFlavors)
                {
                    if (FlavorOfBinToCheck == item.ToString())
                        result = rack[item] == BINSIZE;
                }
            }
            else
            {
                Debug.WriteLine("Error: Unable to check full status of unknown flavor {0}", FlavorOfBinToCheck, DUMMYARGUMENT);
            }

            return result;
        }


        public Boolean IsEmpty(Flavor FlavorOfBinToCheck)
        {
            return IsEmpty(FlavorOfBinToCheck.ToString());
        }

        public Boolean IsEmpty(string FlavorOfBinToCheck)
        {
            bool result = false;

            Debug.WriteLine("Inside bool IsEmpty()");

            if (FlavorOps.AllFlavors.Contains(FlavorOps.ToFlavor(FlavorOfBinToCheck)))
            {
                foreach (var item in FlavorOps.AllFlavors)
                {
                    if (FlavorOfBinToCheck == item.ToString())
                        result = rack[item] == EMPTYBIN;
                }
            }
            else
            {
                Debug.WriteLine("Error: Unable to check empty status of unknown flavor {0}", FlavorOfBinToCheck, DUMMYARGUMENT);
            }

            return result;
        }

        public int RegularCount
        {
            get
            {
                return rack[Flavor.REGULAR];
            }
        }

        public int OrangeCount
        {
            get
            {
                return rack[Flavor.ORANGE];
            }
        }

        public int LemonCount
        {
            get
            {
                return rack[Flavor.LEMON];
            }
        }

    }
}
