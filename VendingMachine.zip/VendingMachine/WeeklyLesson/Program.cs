﻿// Exercise 7 - due Nov 30
// Author: Millora, Romeo

using System; // using directive (works at compile-time, optional)
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics; // allows you to write to the debug window

namespace LiveCodeLesson
{
    class Program
    {
        //static VendingMachine() sodavendingmach = new VendingMachine();
        //static PurchasePrice sodaPrice = new PurchasePrice(0.35M);


        static void Main(string[] args)
        {
            // Exercise 6 - clean up Main
            // Set price in Main
            PurchasePrice P = new PurchasePrice(0.35M);
            VendingMachine VM = new VendingMachine();
            //Coin C = new Coin(); // not needed
            CanRack CR = new CanRack();

            //CoinBox CB = new CoinBox(); // starts with empty coin box
            //Let's start with some coins in the coin box
            CoinBox CB = new CoinBox(new List<Coin> {
                new Coin(Coin.Denomination.QUARTER), new Coin(Coin.Denomination.DIME),
                new Coin(Coin.Denomination.NICKEL), new Coin(Coin.Denomination.QUARTER),
                new Coin(Coin.Denomination.QUARTER), new Coin(Coin.Denomination.DIME) });
            CoinBox tempCB = new CoinBox();


            //processCommandLineArguments(args, P);
            VM.vendingMain(args, P, CB, CR);
            //VM.testVending(CB, CR);

            CB.DisplayCoinBox();
        }


        static void processCommandLineArguments(string[] commandLineArgs, PurchasePrice p)
        {
            string commandLineDenomination;
            decimal commandLineSum = 0;

            Console.WriteLine("Checking if there are any command-line arguments.");

            if (commandLineArgs.Length == 0)
            {
                Console.WriteLine("There are no command-line arguments.");
                Console.WriteLine("Proceeding with vending machine program.");
                Console.WriteLine("\n");
            }
            else
            {
                Console.Write("There were {0} command-line arguments: ", commandLineArgs.Length);
                foreach (string s in commandLineArgs)
                {
                    Console.Write(s + " ");
                }

                Console.WriteLine("\n");

                if (commandLineArgs[0].ToUpper() == "VEND")
                {
                    for (int i = 1; i < commandLineArgs.Length - 1; i++)
                    {
                        commandLineDenomination = commandLineArgs[i].ToUpper();
                        commandLineSum = commandLineSum + (int)Enum.Parse(typeof(Coin.Denomination), commandLineDenomination);
                    }

                    if (commandLineSum / 100 < p.DecimalPrice)
                    {
                        Console.WriteLine("The sum of the coins in the command-line argument is NOT enough for a soda.");
                    }
                    else
                    {
                        Console.WriteLine("The sum of the coins in the command-line argument is {0:C}, which is enough for a soda.", commandLineSum / 100);

                        if (!Enum.IsDefined(typeof(Flavor), commandLineArgs[commandLineArgs.Length - 1].ToUpper()))
                        {
                            Console.WriteLine("The last argument ({0}) was not a valid flavor.", commandLineArgs[commandLineArgs.Length - 1].ToUpper());
                        }
                        else
                        {
                            Console.WriteLine("Thank you. Enjoy your {0} soda!\n", commandLineArgs[commandLineArgs.Length - 1].ToUpper());
                        }
                    }
                }
                else
                {
                    Console.WriteLine("This is an invalid command-line entry.");
                }
            }

        } // end processCommandLineArguments
                        
    }    
    
}
