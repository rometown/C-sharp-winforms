﻿// Exercise 7 - due Nov 30
// Author: Millora, Romeo

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiveCodeLesson
{
    // Exercise 3.2 - create class Can
    public class Can
    {
        //public enum Flavor { REGULAR, ORANGE, LEMON }

        public readonly Flavor TheFlavor = Flavor.REGULAR;

        public Can()
        {

        }

        public Can(Flavor AFlavor)
        {
            TheFlavor = AFlavor;

        }

    }
    
}
