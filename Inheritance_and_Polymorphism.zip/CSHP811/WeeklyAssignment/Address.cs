﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeeklyAssignment
{
    public class Address
    {
        public int City
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int Country
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int State
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }

        public int StreetAddress
        {
            get
            {
                throw new System.NotImplementedException();
            }
            set
            {
            }
        }
    }
}
