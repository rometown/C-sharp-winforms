﻿namespace WeeklyAssignment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabEmployee = new System.Windows.Forms.TabPage();
            this.gbxEmployeeGender = new System.Windows.Forms.GroupBox();
            this.rbtnMaleEmployee = new System.Windows.Forms.RadioButton();
            this.rbtnFemaleEmployee = new System.Windows.Forms.RadioButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblEmployeeDOB = new System.Windows.Forms.Label();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.lblEmployeeId = new System.Windows.Forms.Label();
            this.tabCustomer = new System.Windows.Forms.TabPage();
            this.gbxCustomerGender = new System.Windows.Forms.GroupBox();
            this.rbtnMaleCustomer = new System.Windows.Forms.RadioButton();
            this.rbtnFemaleCustomer = new System.Windows.Forms.RadioButton();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtCustomerId = new System.Windows.Forms.TextBox();
            this.lblCustomerDOB = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblCustomerId = new System.Windows.Forms.Label();
            this.btnSaveToFile = new System.Windows.Forms.Button();
            this.btnSaveToArray = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblNote = new System.Windows.Forms.Label();
            this.btnDisplayPersonArray = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabEmployee.SuspendLayout();
            this.gbxEmployeeGender.SuspendLayout();
            this.tabCustomer.SuspendLayout();
            this.gbxCustomerGender.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabEmployee);
            this.tabControl1.Controls.Add(this.tabCustomer);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(421, 206);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabEmployee
            // 
            this.tabEmployee.Controls.Add(this.gbxEmployeeGender);
            this.tabEmployee.Controls.Add(this.dateTimePicker1);
            this.tabEmployee.Controls.Add(this.txtEmployeeName);
            this.tabEmployee.Controls.Add(this.textBox1);
            this.tabEmployee.Controls.Add(this.lblEmployeeDOB);
            this.tabEmployee.Controls.Add(this.lblEmployeeName);
            this.tabEmployee.Controls.Add(this.lblEmployeeId);
            this.tabEmployee.Location = new System.Drawing.Point(4, 22);
            this.tabEmployee.Name = "tabEmployee";
            this.tabEmployee.Padding = new System.Windows.Forms.Padding(3);
            this.tabEmployee.Size = new System.Drawing.Size(413, 180);
            this.tabEmployee.TabIndex = 0;
            this.tabEmployee.Text = "Employees Tab";
            this.tabEmployee.UseVisualStyleBackColor = true;
            // 
            // gbxEmployeeGender
            // 
            this.gbxEmployeeGender.Controls.Add(this.rbtnMaleEmployee);
            this.gbxEmployeeGender.Controls.Add(this.rbtnFemaleEmployee);
            this.gbxEmployeeGender.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxEmployeeGender.Location = new System.Drawing.Point(217, 61);
            this.gbxEmployeeGender.Name = "gbxEmployeeGender";
            this.gbxEmployeeGender.Size = new System.Drawing.Size(158, 60);
            this.gbxEmployeeGender.TabIndex = 14;
            this.gbxEmployeeGender.TabStop = false;
            this.gbxEmployeeGender.Text = "Gender";
            // 
            // rbtnMaleEmployee
            // 
            this.rbtnMaleEmployee.AutoSize = true;
            this.rbtnMaleEmployee.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMaleEmployee.Location = new System.Drawing.Point(6, 26);
            this.rbtnMaleEmployee.Name = "rbtnMaleEmployee";
            this.rbtnMaleEmployee.Size = new System.Drawing.Size(55, 21);
            this.rbtnMaleEmployee.TabIndex = 12;
            this.rbtnMaleEmployee.TabStop = true;
            this.rbtnMaleEmployee.Text = "Male";
            this.rbtnMaleEmployee.UseVisualStyleBackColor = true;
            this.rbtnMaleEmployee.CheckedChanged += new System.EventHandler(this.radioButtons_CheckedChanged);
            // 
            // rbtnFemaleEmployee
            // 
            this.rbtnFemaleEmployee.AutoSize = true;
            this.rbtnFemaleEmployee.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnFemaleEmployee.Location = new System.Drawing.Point(67, 26);
            this.rbtnFemaleEmployee.Name = "rbtnFemaleEmployee";
            this.rbtnFemaleEmployee.Size = new System.Drawing.Size(67, 21);
            this.rbtnFemaleEmployee.TabIndex = 13;
            this.rbtnFemaleEmployee.TabStop = true;
            this.rbtnFemaleEmployee.Text = "Female";
            this.rbtnFemaleEmployee.UseVisualStyleBackColor = true;
            this.rbtnFemaleEmployee.CheckedChanged += new System.EventHandler(this.radioButtons_CheckedChanged);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(217, 26);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(158, 24);
            this.dateTimePicker1.TabIndex = 11;
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmployeeName.Location = new System.Drawing.Point(6, 26);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(166, 24);
            this.txtEmployeeName.TabIndex = 5;
            this.txtEmployeeName.TextChanged += new System.EventHandler(this.txtEmployeeName_TextChanged);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(6, 84);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(166, 24);
            this.textBox1.TabIndex = 4;
            this.textBox1.Text = "System will choose ID (1xxx)";
            // 
            // lblEmployeeDOB
            // 
            this.lblEmployeeDOB.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeDOB.Location = new System.Drawing.Point(217, 3);
            this.lblEmployeeDOB.Name = "lblEmployeeDOB";
            this.lblEmployeeDOB.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeDOB.Size = new System.Drawing.Size(119, 20);
            this.lblEmployeeDOB.TabIndex = 2;
            this.lblEmployeeDOB.Text = "Employee DOB";
            this.lblEmployeeDOB.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeName.Location = new System.Drawing.Point(6, 3);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeName.Size = new System.Drawing.Size(116, 20);
            this.lblEmployeeName.TabIndex = 1;
            this.lblEmployeeName.Text = "Employee Name";
            this.lblEmployeeName.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lblEmployeeId
            // 
            this.lblEmployeeId.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmployeeId.Location = new System.Drawing.Point(6, 61);
            this.lblEmployeeId.Name = "lblEmployeeId";
            this.lblEmployeeId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblEmployeeId.Size = new System.Drawing.Size(119, 20);
            this.lblEmployeeId.TabIndex = 0;
            this.lblEmployeeId.Text = "Employee ID";
            this.lblEmployeeId.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // tabCustomer
            // 
            this.tabCustomer.Controls.Add(this.gbxCustomerGender);
            this.tabCustomer.Controls.Add(this.dateTimePicker2);
            this.tabCustomer.Controls.Add(this.txtCustomerName);
            this.tabCustomer.Controls.Add(this.txtCustomerId);
            this.tabCustomer.Controls.Add(this.lblCustomerDOB);
            this.tabCustomer.Controls.Add(this.lblCustomerName);
            this.tabCustomer.Controls.Add(this.lblCustomerId);
            this.tabCustomer.Location = new System.Drawing.Point(4, 22);
            this.tabCustomer.Name = "tabCustomer";
            this.tabCustomer.Padding = new System.Windows.Forms.Padding(3);
            this.tabCustomer.Size = new System.Drawing.Size(413, 180);
            this.tabCustomer.TabIndex = 1;
            this.tabCustomer.Text = "Customers Tab";
            this.tabCustomer.UseVisualStyleBackColor = true;
            // 
            // gbxCustomerGender
            // 
            this.gbxCustomerGender.Controls.Add(this.rbtnMaleCustomer);
            this.gbxCustomerGender.Controls.Add(this.rbtnFemaleCustomer);
            this.gbxCustomerGender.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxCustomerGender.Location = new System.Drawing.Point(217, 61);
            this.gbxCustomerGender.Name = "gbxCustomerGender";
            this.gbxCustomerGender.Size = new System.Drawing.Size(158, 60);
            this.gbxCustomerGender.TabIndex = 26;
            this.gbxCustomerGender.TabStop = false;
            this.gbxCustomerGender.Text = "Gender";
            // 
            // rbtnMaleCustomer
            // 
            this.rbtnMaleCustomer.AutoSize = true;
            this.rbtnMaleCustomer.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMaleCustomer.Location = new System.Drawing.Point(6, 26);
            this.rbtnMaleCustomer.Name = "rbtnMaleCustomer";
            this.rbtnMaleCustomer.Size = new System.Drawing.Size(55, 21);
            this.rbtnMaleCustomer.TabIndex = 24;
            this.rbtnMaleCustomer.TabStop = true;
            this.rbtnMaleCustomer.Text = "Male";
            this.rbtnMaleCustomer.UseVisualStyleBackColor = true;
            this.rbtnMaleCustomer.CheckedChanged += new System.EventHandler(this.radioButtons_CheckedChanged);
            // 
            // rbtnFemaleCustomer
            // 
            this.rbtnFemaleCustomer.AutoSize = true;
            this.rbtnFemaleCustomer.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnFemaleCustomer.Location = new System.Drawing.Point(67, 26);
            this.rbtnFemaleCustomer.Name = "rbtnFemaleCustomer";
            this.rbtnFemaleCustomer.Size = new System.Drawing.Size(67, 21);
            this.rbtnFemaleCustomer.TabIndex = 25;
            this.rbtnFemaleCustomer.TabStop = true;
            this.rbtnFemaleCustomer.Text = "Female";
            this.rbtnFemaleCustomer.UseVisualStyleBackColor = true;
            this.rbtnFemaleCustomer.CheckedChanged += new System.EventHandler(this.radioButtons_CheckedChanged);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(217, 26);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(158, 24);
            this.dateTimePicker2.TabIndex = 23;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerName.Location = new System.Drawing.Point(6, 26);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(166, 24);
            this.txtCustomerName.TabIndex = 19;
            this.txtCustomerName.TextChanged += new System.EventHandler(this.txCustomerName_TextChanged);
            // 
            // txtCustomerId
            // 
            this.txtCustomerId.Enabled = false;
            this.txtCustomerId.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerId.Location = new System.Drawing.Point(6, 84);
            this.txtCustomerId.Name = "txtCustomerId";
            this.txtCustomerId.Size = new System.Drawing.Size(166, 23);
            this.txtCustomerId.TabIndex = 18;
            this.txtCustomerId.Text = "System will choose ID (5xxx)";
            // 
            // lblCustomerDOB
            // 
            this.lblCustomerDOB.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerDOB.Location = new System.Drawing.Point(217, 3);
            this.lblCustomerDOB.Name = "lblCustomerDOB";
            this.lblCustomerDOB.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblCustomerDOB.Size = new System.Drawing.Size(119, 20);
            this.lblCustomerDOB.TabIndex = 16;
            this.lblCustomerDOB.Text = "Customer DOB";
            this.lblCustomerDOB.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerName.Location = new System.Drawing.Point(6, 3);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblCustomerName.Size = new System.Drawing.Size(119, 20);
            this.lblCustomerName.TabIndex = 15;
            this.lblCustomerName.Text = "Customer Name";
            this.lblCustomerName.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // lblCustomerId
            // 
            this.lblCustomerId.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerId.Location = new System.Drawing.Point(6, 61);
            this.lblCustomerId.Name = "lblCustomerId";
            this.lblCustomerId.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblCustomerId.Size = new System.Drawing.Size(119, 20);
            this.lblCustomerId.TabIndex = 14;
            this.lblCustomerId.Text = "Customer ID";
            this.lblCustomerId.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // btnSaveToFile
            // 
            this.btnSaveToFile.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveToFile.Location = new System.Drawing.Point(294, 224);
            this.btnSaveToFile.Name = "btnSaveToFile";
            this.btnSaveToFile.Size = new System.Drawing.Size(135, 40);
            this.btnSaveToFile.TabIndex = 22;
            this.btnSaveToFile.Text = "Save to File";
            this.btnSaveToFile.UseVisualStyleBackColor = true;
            this.btnSaveToFile.Click += new System.EventHandler(this.btnSaveToFile_Click);
            // 
            // btnSaveToArray
            // 
            this.btnSaveToArray.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveToArray.Location = new System.Drawing.Point(153, 224);
            this.btnSaveToArray.Name = "btnSaveToArray";
            this.btnSaveToArray.Size = new System.Drawing.Size(135, 40);
            this.btnSaveToArray.TabIndex = 21;
            this.btnSaveToArray.Text = "Save to Array";
            this.btnSaveToArray.UseVisualStyleBackColor = true;
            this.btnSaveToArray.Click += new System.EventHandler(this.btnSaveToArray_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(12, 224);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(135, 40);
            this.btnClear.TabIndex = 20;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblNote
            // 
            this.lblNote.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNote.Location = new System.Drawing.Point(9, 328);
            this.lblNote.Name = "lblNote";
            this.lblNote.Size = new System.Drawing.Size(279, 40);
            this.lblNote.TabIndex = 23;
            this.lblNote.Text = "Note: Person data text file is saved on your desktop.";
            // 
            // btnDisplayPersonArray
            // 
            this.btnDisplayPersonArray.Font = new System.Drawing.Font("Calibri", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDisplayPersonArray.Location = new System.Drawing.Point(294, 328);
            this.btnDisplayPersonArray.Name = "btnDisplayPersonArray";
            this.btnDisplayPersonArray.Size = new System.Drawing.Size(135, 40);
            this.btnDisplayPersonArray.TabIndex = 24;
            this.btnDisplayPersonArray.Text = "Display Person Array";
            this.btnDisplayPersonArray.UseVisualStyleBackColor = true;
            this.btnDisplayPersonArray.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(453, 380);
            this.Controls.Add(this.btnDisplayPersonArray);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnSaveToFile);
            this.Controls.Add(this.btnSaveToArray);
            this.Controls.Add(this.btnClear);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Millora04 - Employee and Customer Form";
            this.tabControl1.ResumeLayout(false);
            this.tabEmployee.ResumeLayout(false);
            this.tabEmployee.PerformLayout();
            this.gbxEmployeeGender.ResumeLayout(false);
            this.gbxEmployeeGender.PerformLayout();
            this.tabCustomer.ResumeLayout(false);
            this.tabCustomer.PerformLayout();
            this.gbxCustomerGender.ResumeLayout(false);
            this.gbxCustomerGender.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabCustomer;
        private System.Windows.Forms.RadioButton rbtnFemaleCustomer;
        private System.Windows.Forms.RadioButton rbtnMaleCustomer;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button btnSaveToFile;
        private System.Windows.Forms.Button btnSaveToArray;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.TextBox txtCustomerId;
        private System.Windows.Forms.Label lblCustomerDOB;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblCustomerId;
        private System.Windows.Forms.GroupBox gbxCustomerGender;
        private System.Windows.Forms.TabPage tabEmployee;
        private System.Windows.Forms.GroupBox gbxEmployeeGender;
        private System.Windows.Forms.RadioButton rbtnMaleEmployee;
        private System.Windows.Forms.RadioButton rbtnFemaleEmployee;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblEmployeeDOB;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label lblEmployeeId;
        private System.Windows.Forms.Label lblNote;
        private System.Windows.Forms.Button btnDisplayPersonArray;
    }
}

