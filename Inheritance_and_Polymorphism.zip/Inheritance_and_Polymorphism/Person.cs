﻿// Author: Millora, Romeo
// Assignment 04
// Due: Feb. 22

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeeklyAssignment
{
    public abstract class Person
    {
        private DateTime dtDOB;
        private Gender enmGender;
        private string strName;
        internal int TestInternal;
        protected int TestProtected;
        protected internal int TestProtectedInternal;

        public event EventHandler DOBChanged;

        public event EventHandler GenderChanged;

        public event EventHandler NameChanged;

        public Person() : this("", DateTime.Now, Gender.Female)
        {
            //Name = "";
            //DOB = DateTime.Now;
            //Gender = Gender.Female;          

            Console.WriteLine("This will be processed AFTER the 3 argument constructor");

            //NewMethod("", DateTime.Now, Gender.Female);
        }

        public Person(string Name, DateTime DOB, Gender Gender)
        {
            //NewMethod( Name,  DOB,  Gender); 
            this.Name = Name;
            this.dtDOB = DOB;
            this.Gender = Gender;
        }

        public DateTime DOB
        {
            get
            {
                return dtDOB;
            }
            set
            {

                try
                {
                    if (value > DateTime.Now)
                    {
                        throw new Exception("DOB cannot be in the future!");
                    }
                    dtDOB = value;
                    if (DOBChanged != null)
                    {
                        DOBChanged(this, new EventArgs());
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        public Gender Gender
        {
            get
            {
                return enmGender;
            }
            set
            {
                enmGender = value;
                if (GenderChanged != null)
                {
                    GenderChanged(this, new EventArgs());
                }
            }
        }

        public string Name
        {
            get
            {

                try
                {
                    if (string.IsNullOrEmpty(strName))
                    {
                        throw new Exception("Name has not be set to a value!");
                    }
                    return strName;
                }
                catch (Exception)
                {
                    throw;
                }

            }
            set
            {
                try
                {
                    foreach (char chrLetter in (string)value)
                    {
                        if (char.IsDigit(chrLetter))
                        {
                            throw new Exception("Numbers are not allowed in a name.");
                        }
                    }

                    strName = value;
                    if (NameChanged != null)
                    {
                        NameChanged(this, new EventArgs());
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// Returns all the data in a Person object
        /// </summary>
        public virtual string GetData()
        {
            return Name + "," + DOB.ToLongDateString() + "," + Gender.ToString(); 
        }
    }
}
