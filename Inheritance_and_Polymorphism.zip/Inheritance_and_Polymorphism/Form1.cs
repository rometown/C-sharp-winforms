﻿// Author: Millora, Romeo
// Assignment 04
// Due: Feb. 22

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;


namespace WeeklyAssignment
{
    public partial class Form1 : Form
    {
        /*
        ---------- USING A LIST ----------
        // Ideally, a List should be used to store Employee or Customer information.
        List<Person> personList = new List<Person>();
        
        // We could also use 2 separate lists
        List<Employee> employeeList = new List<Employee>();
        List<Customer> customerList = new List<Customer>();        
        */

        private const int SIZE = 20;

        Person[] personList = new Person[SIZE];
        private int InsertInArrayId = 0;        // so we know where in the array to insert new Employee or Customer
        private int PersonInArrayCounter = 0;   // show how many persons are saved in array, and not yet saved to file

        public Form1()
        {
            InitializeComponent();

            ResetButtons();
        }


        private void btnSaveToArray_Click(object sender, EventArgs e)
        {
            // Typically, I would let SQL Server handle this using an incremental unique ID field.
            // I will not allow user to enter a unique ID, such as employee or customer ID.
            // For now, I'll generate a random number in lieu of sql server.
            Random rnd = new Random();

            if (tabControl1.SelectedTab == tabEmployee)
            {
                if (!MissingRequiredFields())
                {
                    // If using List<>
                    //employeeList.Add(new Employee(rnd.Next(1000, 1999), txtEmployeeName.Text, DateTime.Parse(dateTimePicker1.Value.ToShortDateString()), rbtnMaleEmployee.Checked ? Gender.Male : Gender.Female));

                    // Use if Employee and Customer data need to be on a separate array.
                    //employeeList[employeeArrayId] = new Employee(rnd.Next(1000, 1999), txtEmployeeName.Text, DateTime.Parse(dateTimePicker1.Value.ToShortDateString()), rbtnMaleEmployee.Checked ? Gender.Male : Gender.Female);


                    personList[InsertInArrayId] = new Employee(rnd.Next(1000, 1999), txtEmployeeName.Text, DateTime.Parse(dateTimePicker1.Value.ToShortDateString()), rbtnMaleEmployee.Checked ? Gender.Male : Gender.Female);
                    InsertInArrayId++;
                    PersonInArrayCounter++;

                    btnSaveToFile.Text = "Save To File (" + PersonInArrayCounter + ")";
                    MessageBox.Show("Employee info saved to Person array.");

                    ClearFields();

                    ResetButtons();
                }
                else
                {
                    // Do nothing. User has been told what fields are missing inside bool MissingRequiredFields()
                }
            }
            else // Customer tab selected
            {
                if (!MissingRequiredFields())
                {
                    // If using List<>
                    //customerList.Add(new Customer(rnd.Next(5000, 5999), txtCustomerName.Text, DateTime.Parse(dateTimePicker2.Value.ToShortDateString()), rbtnMaleCustomer.Checked ? Gender.Male : Gender.Female));

                    // Use if Employee and Customer data need to be on a separate array.
                    //customerList[customerArrayId] = new Customer(rnd.Next(5000, 5999), txtCustomerName.Text, DateTime.Parse(dateTimePicker2.Value.ToShortDateString()), rbtnMaleCustomer.Checked ? Gender.Male : Gender.Female);


                    personList[InsertInArrayId] = new Customer(rnd.Next(5000, 5999), txtCustomerName.Text, DateTime.Parse(dateTimePicker2.Value.ToShortDateString()), rbtnMaleCustomer.Checked ? Gender.Male : Gender.Female);
                    InsertInArrayId++;
                    PersonInArrayCounter++;

                    btnSaveToFile.Text = "Save To File (" + PersonInArrayCounter + ")";
                    MessageBox.Show("Customer info saved to Person array.");

                    ClearFields();

                    ResetButtons();
                }
                else
                {
                    // Do nothing. User has been told what fields are missing inside bool MissingRequiredFields()
                }
            }
        }

        private void DisplayPersonArray()
        {

            // For more extensibility.. 
            string output = string.Empty;

            if(InsertInArrayId == 0)
            {
                output = "Empty";
            }
            else
            { 
                for (int i = 0; i < InsertInArrayId; i++)
                {
                    output += personList[i].GetData() + "\n";
                }
            }

            MessageBox.Show("Contents of personList[]:\n\n" + output);
        }

        private void btnSaveToFile_Click(object sender, EventArgs e)
        {
            string DesktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filename = "PersonData.txt";

            try
            {
                System.IO.StreamWriter objSW;
                objSW = new System.IO.StreamWriter(DesktopPath + "\\" + filename);

                /*
                // If using List<>
                foreach (var element in employeeList)
                {
                    // For debug
                    //MessageBox.Show(element.GetData());

                    objSW.WriteLine(element.GetData());
                }
                */


                for (int i = 0; i < InsertInArrayId; i++)
                {
                    objSW.WriteLine(personList[i].GetData());
                }

                objSW.Close();

                MessageBox.Show("Info saved to " + filename + " on your desktop.");

                PersonInArrayCounter = 0;
                btnSaveToFile.Text = "Save To File (" + PersonInArrayCounter + ")";

                ResetButtons();

            }
            catch (Exception ex)
            {
                throw new ApplicationException(string.Format("I cannot write the file {0} to {1}", filename, DesktopPath), ex);
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();

            ResetButtons();
        }

        private void ClearFields()
        {
            if (tabControl1.SelectedTab == tabEmployee)
            {
                rbtnMaleEmployee.Checked = false;
                rbtnFemaleEmployee.Checked = false;
                txtEmployeeName.Text = "";
                dateTimePicker1.Value = DateTime.Now.Date;
            }
            else
            {
                rbtnMaleCustomer.Checked = false;
                rbtnFemaleCustomer.Checked = false;
                txtCustomerName.Text = "";
                dateTimePicker2.Value = DateTime.Now.Date;
            }
        }

        private bool MissingRequiredFields()
        {
            if (tabControl1.SelectedTab == tabEmployee)
            {
                if (txtEmployeeName.Text == "")
                {
                    MessageBox.Show("Please enter name.");

                    return true;
                }
                // at least one radiobutton in groupbox1 is checked
                else if (!gbxEmployeeGender.Controls.OfType<RadioButton>().Any(x => x.Checked))
                {
                    MessageBox.Show("Please choose a gender.");

                    return true;
                }
                else
                {
                    return false;
                }
            }
            else // Customer tab selected
            {
                if (txtCustomerName.Text == "")
                {
                    MessageBox.Show("Please enter name.");

                    return true;
                }
                // at least one radiobutton in groupbox1 is checked
                else if (!gbxCustomerGender.Controls.OfType<RadioButton>().Any(x => x.Checked))
                {
                    MessageBox.Show("Please choose a gender.");

                    return true;
                }
                else
                {
                    return false;
                }
            }
        }


        private void ResetButtons()
        {
            // reset Clear and Save To Array buttons
            if (tabControl1.SelectedTab == tabEmployee)
            {
                if (txtEmployeeName.Text.Trim() != "")
                {
                    btnSaveToArray.Enabled = true;
                    btnClear.Enabled = true;
                }
                else if (txtEmployeeName.Text.Trim() == "" && gbxEmployeeGender.Controls.OfType<RadioButton>().Any(x => x.Checked))
                {
                    btnSaveToArray.Enabled = false;
                    btnClear.Enabled = true;
                }
                else
                {
                    btnSaveToArray.Enabled = false;
                    btnClear.Enabled = false;
                }
            }
            else // Customer tab selected
            {
                if (txtCustomerName.Text.Trim() != "")
                {
                    btnSaveToArray.Enabled = true;
                    btnClear.Enabled = true;
                }
                else if (txtCustomerName.Text.Trim() == "" && gbxCustomerGender.Controls.OfType<RadioButton>().Any(x => x.Checked))
                {
                    btnSaveToArray.Enabled = false;
                    btnClear.Enabled = true;
                }
                else
                {
                    btnSaveToArray.Enabled = false;
                    btnClear.Enabled = false;
                }
            }

            // reset Save To File button
            if (PersonInArrayCounter > 0)
            {
                btnSaveToFile.Enabled = true;
            }
            else
            {
                btnSaveToFile.Enabled = false;
            }

        }


        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetButtons();
        }

        private void radioButtons_CheckedChanged(object sender, EventArgs e)
        {
            ResetButtons();
        }

        private void txtEmployeeName_TextChanged(object sender, EventArgs e)
        {
            ResetButtons();
        }

        private void txCustomerName_TextChanged(object sender, EventArgs e)
        {
            ResetButtons();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DisplayPersonArray();
        }
    }
}
