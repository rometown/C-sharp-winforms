﻿// Author: Millora, Romeo
// Assignment 04
// Due: Feb. 22

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WeeklyAssignment
{
    public class Customer : Person
    {
        private int intCustomerId;

        public Customer() : base()
        {
            //
        }

        public Customer(int CustomerId, string Name, DateTime DOB, Gender Gender) : base(Name, DOB, Gender) 
        {
            this.CustomerId = CustomerId;
            // this.Name = Name; This is not needed since the base constructor will be 
            // passed the data in with  :base(Name, DOB, Gender) 
        }

        public int CustomerId
        {
            get { return intCustomerId; }
            set { intCustomerId = value; }
        }

        
        //public new string GetData()
        public override string GetData()
        {
            //Won't work since these FIELDS are marked "private" : return CustomerId.ToString() + strName + dtDOB + enmGender.ToString();
            //return CustomerId.ToString() + Name + DOB + Gender.ToString();
            return CustomerId.ToString() + "," + base.GetData();
        }
    }
}
